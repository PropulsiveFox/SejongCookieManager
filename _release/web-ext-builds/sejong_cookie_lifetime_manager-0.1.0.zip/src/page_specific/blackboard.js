// if (navigator.userAgent.toLowerCase().includes('chrome')) {
// 	chrome.runtime.sendMessage('kmitb');
// }
// else browser.runtime.sendMessage('kmitb');
